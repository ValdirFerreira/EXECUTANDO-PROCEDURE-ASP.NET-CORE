﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebProcedures.Models;

namespace WebProcedures.Controllers
{
    public class ItensProdutoController : Controller
    {

        private readonly Contexto _context;


        public ItensProdutoController(Contexto Contexto)
        {
            _context = Contexto;
        }

        public async Task<IActionResult> Index()
        {

            var param = new SqlParameter("@id", 2);
            var listaRetorno = await _context.ItemProdutoViewModel.FromSql("ItensProdutos @id", param).ToListAsync();

            return View(listaRetorno);
        }
    }
}
